class FileToFingerprint():
    def __init__(self, filename, fileid, keys, similarto):
        self.filename = filename
        self.fileid = fileid
        self.keys = keys
        self.similarto = similarto