# SourceAnalyzer

https://theory.stanford.edu/~aiken/publications/papers/sigmod03.pdf
