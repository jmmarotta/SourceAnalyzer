# SourceAnalyzer

- A locally run application that demonstrates different matching algorithms ( winnowing, ... , ... )
- Developed as a one to one connection
- Outputs given percentage of similarity and highlighted visualization of the matching sections of input documents
- Supports, raw text and python currently, with C++ and java planned in the future

## Getting Started

#### STEP 1

run command

    pip install


##### OR

Download



then run command

    pip3 install /<file_path>/source_analyzer-0.1.18.tar.gz


#### STEP 2

run command

    source_analyzer



## Project Group: Codalyzers
- Djoni Austin | @dcaustin
- Jared Dawson | @lukinator1
- Shane Eising | @seising99
- Julian Marott | @jmmoratta

## References: 
https://theory.stanford.edu/~aiken/publications/papers/sigmod03.pdf

