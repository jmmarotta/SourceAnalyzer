# a theoretical innocent person who's program does the same fundamental thing as # test1.py, but, wasn't copied
def main():
    x = 1.5
    y = 6.3
    sum = x + y
    y = 6.3 + 0 + 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10
    print("The first digit", x, "and", y, "added together equal", sum)

    u = 3
    v = 9
    sum = 3 + 9 
    print("The first digit", u, "and", v, "added together equal", sum)

main()

